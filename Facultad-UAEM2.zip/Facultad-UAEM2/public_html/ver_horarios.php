<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Horarios</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <header>
        <h1>Horarios Generados</h1>
    </header>
    <div class="container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Materia</th>
                    <th>Horario</th>
                    <th>Profesor</th>
                </tr>
            </thead>
            <tbody>
                <!-- Aquí se insertan los horarios dinámicamente con PHP -->
            </tbody>
        </table>
    </div>
</body>
</html>
