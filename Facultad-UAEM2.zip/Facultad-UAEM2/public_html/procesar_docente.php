<?php include('conexion.php'); ?>

<h1>Modificar Datos de un Docente</h1>

<!-- Formulario para buscar un docente -->
<form action="guardar_registro.php" method="GET">
    <div class="mb-3">
         <label for="nombre">Nombre del Docente:</label>
                <input type="text" id="nombre" name="nombre" required>
    </div>
    <button type="submit">Buscar Docente</button>
</form>

<?php
if (isset($_GET['id_docente'])) {
    $id_docente = $_GET['id_docente'];
    $sql = "SELECT * FROM docentes WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $id_docente);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $docente = $result->fetch_assoc();
?>
        <!-- Formulario para modificar los datos -->
        <form action="guardar_modificacion.php" method="POST">
            

            <div class="mb-3">
                <label for="nombre">Nombre completo:</label>
                <input type="text" id="nombre" name="nombre" value="<?= $docente['nombre'] ?>" required>
            </div>

            <div class="mb-3">
                <label for="correo">Correo electrónico:</label>
                <input type="email" id="correo" name="correo" value="<?= $docente['correo'] ?>" required>
            </div>

            <div class="mb-3">
                <label for="materia">Materia:</label>
                <input type="text" id="materia" name="materia" value="<?= $docente['materia'] ?>" required>
            </div>

            <div class="mb-3">
                <label for="carrera">Carrera:</label>
                <select id="carrera" name="carrera" required>
                    <option value="administracion" <?= $docente['carrera'] == 'administracion' ? 'selected' : '' ?>>Administración</option>
                    <option value="contaduria" <?= $docente['carrera'] == 'contaduria' ? 'selected' : '' ?>>Contaduría</option>
                    <option value="economia" <?= $docente['carrera'] == 'economia' ? 'selected' : '' ?>>Economía</option>
                    <option value="informatica" <?= $docente['carrera'] == 'informatica' ? 'selected' : '' ?>>Informática</option>
                </select>
            </div>

            <div class="mb-3">
                <label for="semestre">Semestre:</label>
                <select id="semestre" name="semestre" required>
                    <?php for ($i = 1; $i <= 13; $i++): ?>
                        <option value="<?= $i ?>" <?= $docente['semestre'] == $i ? 'selected' : '' ?>><?= $i ?>º semestre</option>
                    <?php endfor; ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="grupo">Grupo:</label>
                <select id="grupo" name="grupo" required>
                    <option value="A" <?= $docente['grupo'] == 'A' ? 'selected' : '' ?>>A</option>
                    <option value="B" <?= $docente['grupo'] == 'B' ? 'selected' : '' ?>>B</option>
                    <option value="C" <?= $docente['grupo'] == 'C' ? 'selected' : '' ?>>C</option>
                    <option value="U" <?= $docente['grupo'] == 'U' ? 'selected' : '' ?>>U</option>
                </select>
            </div>

            <div class="mb-3">
                <label for="horario">Horario:</label>
                <input type="text" id="horario" name="horario" value="<?= $docente['horario'] ?>" required>
            </div>

            <div class="mb-3">
                <label for="alumnos">Número de Alumnos:</label>
                <input type="number" id="alumnos" name="alumnos" value="<?= $docente['alumnos'] ?>" required>
            </div>

            <div class="mb-3">
                <label for="programas">Programas:</label>
                <input type="text" id="programas" name="programas" value="<?= $docente['programas'] ?>" required>
            </div>

            <button type="submit">Guardar Cambios</button>
        </form>
<?php
    } else {
        echo "<p>No se encontró un docente con ese ID.</p>";
    }
    $stmt->close();
}
$conn->close();
?>


